<?php

function themedsrd_menu() {
  register_nav_menu('main-menu-left', __('Menu principal gauche'));
  register_nav_menu('main-menu-right', __('Menu principal droit'));
}
add_action('init', 'themedsrd_menu');

function themedsrd_customizer_header($wp_customize) {
  // Add section for upload logo
  $wp_customize->add_section(
    'header_section',
    [
      'title' => 'Header',
      'priority' => 20,
    ]
  );

  // Add a parameter for logo
  $wp_customize->add_setting('header_logo');

  // Add a control to upload logo
  $wp_customize->add_control(
    new WP_Customize_Image_Control(
      $wp_customize, 'header_logo',
      array(
        'label' => __('Télécharger le logo :'),
        'section' => 'header_section',
        'settings' => 'header_logo'
      )
    )
  );
}
add_action('customize_register', 'themedsrd_customizer_header');

function themedsrd_styles() {
  wp_enqueue_style('style_css', get_template_directory_uri() . '/style.css');
}
add_action('wp_enqueue_scripts', 'themedsrd_styles');
