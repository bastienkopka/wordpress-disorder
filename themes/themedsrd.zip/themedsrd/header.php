<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="Maxence LEBLOND">
        <title><?php the_title(); ?></title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css" integrity="sha512-NmLkDIU1C/C88wi324HBc+S2kLhi08PN5GDeUVVVC/BVt/9Izdsc9SVeVfA1UZbY3sHUlDSyRXhCzHfr6hmPPw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
        <header class="l-header">

<!--            <div class="l-header__container">-->
<!--              <div class="search">-->
<!--                <button><i class="fa-solid fa-magnifying-glass"></i></button>-->
<!--              </div>-->
<!---->
<!--              <div class="l-header__left">-->
<!--                <div class="header-section">-->
<!--                  <div class="social">-->
<!--                    <a href=""><i class="fa-brands fa-facebook"></i></a>-->
<!--                    <a href=""><i class="fa-brands fa-twitch"></i></a>-->
<!--                  </div>-->
<!---->
<!--                  <div class="menu">-->
<!--                    <ul class="menu__left">-->
<!--                      <li><a href="">Accueil</a></li>-->
<!--                      <li><a href="">Disorder+</a></li>-->
<!--                      <li><a href="">Video</a></li>-->
<!--                    </ul>-->
<!--                  </div>-->
<!--                </div>-->
<!--              </div>-->
<!---->
<!--              <div class="l-header__middle">-->
<!--                <div class="logo">-->
<!--                  <a href="" class="logo__link">-->
<!--                    <img src="" title="" alt="" />-->
<!--                  </a>-->
<!--                </div>-->
<!--              </div>-->
<!---->
<!--              <div class="l-header__right">-->
<!--                <div class="header-section"></div>-->
<!---->
<!--                <div class="menu">-->
<!--                  <ul class="menu__right">-->
<!--                    <li><a href="">Multi-gaming</a></li>-->
<!--                    <li><a href="">Actus</a></li>-->
<!--                    <li><a href="">Star citizen+</a></li>-->
<!--                  </ul>-->
<!--                </div>-->
<!--              </div>-->
<!--            </div>-->



            <button><i class="fa-solid fa-magnifying-glass"></i></button>
            <div id=reseau>
              <a href=""><i class="fa-brands fa-facebook"></i></a>
              <a href=""><i class="fa-brands fa-twitch"></i></a>
              <a href=""><i class="fa-brands fa-youtube"></i></a>
              <a href=""><i class="fa-brands fa-tiktok"></i></a>
              <a href=""><i class="fa-brands fa-discord"></i></a>
            </div>

            <?php wp_nav_menu([
              'theme_location' => 'main-menu-left',
              'container_class' => 'menu',
              'menu_class' => 'menu__left',
            ]); ?>

            <?php if (get_theme_mod('header_logo')) : ?>
              <img src="<?php echo get_theme_mod('header_logo'); ?>" />
            <?php endif; ?>

            <?php wp_nav_menu([
              'theme_location' => 'main-menu-right',
              'container_class' => 'menu',
              'menu_class' => 'menu__right',
            ]); ?>

            <button><i class="fa-solid fa-right-to-bracket"></i></button>
        </header>